package app.controller;

import java.io.IOException;
import javafx.fxml.FXML;
import app.App;

public class SecondaryController {

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }
}